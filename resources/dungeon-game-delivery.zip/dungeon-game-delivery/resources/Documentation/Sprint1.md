**Sprint 1**

1.1 Show maze\
1.2 build logical map from text file\
1.3 Allow character to be steered around maze using arrow keys.\
1.4 Show “win” screen when maze is complete
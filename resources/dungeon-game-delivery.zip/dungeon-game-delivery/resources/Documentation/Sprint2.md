**Sprint 2**

SPRINT2.1: Add screen so user enters name before start\
SPRINT2.2: Display "time remaining" on maze (counting down)\
SPRINT2.3: Create Rat that follows player. Show "lose" screen if rat hits player\
SPRINT2.4: Display user name and time remaining (score) when maze completed\
SPRINT2.5 Document 1: User Manual: scenario-driven explanation of how to use the product\
SPRINT2.6 Document 2: Installation Guide: simple, self-explanatory, written in user’s language\
SPRINT2.7 Document 3: Maintenance Guide: detailed sign-posting of how to navigate the code and where and how to make extensions.\
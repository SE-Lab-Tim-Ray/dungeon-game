**Sprint 3**

SPRINT3.1: Display leader board after win or lose screen with "time remaining" score and name\
SPRINT3.2: add another rat\
SPRINT3.3: Modify maze to make more playable with more breaks in walls\
SPRINT3.4: Add better commenting on all files\
SPRINT3.5: Finish product documentation \
SPRINT3.6: appearing walls \
SPRINT3.7: Delivery method \
SPRINT3.8: Scene setting \
SPRINT3.9: Key in 4 peices \
SPRINT3.10: Ability to replay \
SPRINT3.11: CRC Card update \
SPRINT3.12: Unit testing \
SPRINT3.13: Functional testing\
SPRINT3.14: merge to master \



